# Java-Tetris-Game
Java Tetris game clone source code. Uses Java 12.  
https://zetcode.com/javagames/tetris/

![Tetris game screenshot](tetris_game.png)

